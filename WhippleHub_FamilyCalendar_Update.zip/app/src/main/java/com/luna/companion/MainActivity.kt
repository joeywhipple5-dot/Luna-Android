package com.luna.companion

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Night = Color(0xFF15121E)
private val Panel = Color(0xFF211B2D)
private val Purple = Color(0xFF9D7BEA)
private val Lilac = Color(0xFFE6DAFF)
private val Muted = Color(0xFFB9B0C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WhippleHubApp(this) }
    }
}

data class LunaEntry(
    val title: String,
    val detail: String = "",
    val category: String = ""
)

private val sections = listOf(
    "Home", "TV Shows", "Projects", "Family Calendar", "Shopping",
    "Ideas Workshop", "Memory", "WhippleHub Chat", "Update Center"
)

@Composable
fun WhippleHubApp(context: Context) {
    var current by remember { mutableStateOf("Home") }
    var entries by remember { mutableStateOf(loadAll(context)) }
    var draft by remember { mutableStateOf("") }
    var detailDraft by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Currently watching") }
    var showComposer by remember { mutableStateOf(false) }
    var chatText by remember { mutableStateOf("") }
    var chatLog by remember { mutableStateOf(listOf("WhippleHub: Welcome! AI features will be connected in a later build.")) }

    fun save() { saveAll(context, entries) }
    fun addEntry(section: String, title: String, detail: String = "", cat: String = "") {
        if (title.isBlank()) return
        val updated = entries.toMutableMap()
        updated[section] = (updated[section] ?: emptyList()) + LunaEntry(title.trim(), detail.trim(), cat)
        entries = updated
        save()
        draft = ""
        detailDraft = ""
        showComposer = false
    }
    fun removeEntry(section: String, index: Int) {
        val updated = entries.toMutableMap()
        updated[section] = (updated[section] ?: emptyList()).toMutableList().also { if (index in it.indices) it.removeAt(index) }
        entries = updated
        save()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            onPrimary = Color.White,
            background = Night,
            surface = Panel,
            onSurface = Lilac,
            onBackground = Lilac,
            secondary = Lilac
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(42.dp).background(Purple.copy(alpha = .22f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.AutoAwesome, null, tint = Lilac) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("WhippleHub", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Lilac)
                        Text("Your life. One place.", fontSize = 12.sp, color = Muted)
                        Text("A Product by Whipple Corporation", fontSize = 9.sp, color = Muted)
                    }
                    IconButton(onClick = { current = "Update Center" }) {
                        Icon(Icons.Default.SystemUpdateAlt, "Updates", tint = Lilac)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    sections.forEach { item ->
                        FilterChip(
                            selected = current == item,
                            onClick = { current = item; showComposer = false },
                            label = { Text(item, maxLines = 1) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Purple,
                                selectedLabelColor = Color.White,
                                labelColor = Muted
                            )
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                when (current) {
                    "Home" -> HomeScreen(entries, onOpen = { current = it })
                    "WhippleHub Chat" -> ChatScreen(chatLog, chatText, { chatText = it }, {
                        if (chatText.isNotBlank()) {
                            chatLog = chatLog + "You: ${chatText.trim()}" +
                                "WhippleHub: I can help organize your plans. AI integration is planned after the core features are built."
                            chatText = ""
                        }
                    })
                    "Update Center" -> UpdateScreen()
                    "Family Calendar" -> CalendarScreen(
                        entries = entries["Family Calendar"] ?: emptyList(),
                        onAdd = { title, date, time, child, location, notes, repeat ->
                            val details = "TIME=$time\nCHILD=$child\nLOCATION=$location\nREPEAT=$repeat\nNOTES=$notes"
                            addEntry("Family Calendar", title, details, date)
                        },
                        onDelete = { index -> removeEntry("Family Calendar", index) }
                    )
                    else -> {
                        val isShows = current == "TV Shows"
                        val isIdeas = current == "Ideas Workshop"
                        val isCalendar = current == "Family Calendar"
                        val list = entries[current] ?: emptyList()
                        Column(Modifier.weight(1f)) {
                            Text(current, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Lilac)
                            Spacer(Modifier.height(5.dp))
                            Text(sectionSubtitle(current), color = Muted, fontSize = 13.sp)
                            if (isShows) {
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    listOf("Watched", "Currently watching", "Watchlist").forEach { cat ->
                                        FilterChip(
                                            selected = category == cat,
                                            onClick = { category = cat },
                                            label = { Text(cat, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                            if (showComposer) {
                                Spacer(Modifier.height(12.dp))
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = draft, onValueChange = { draft = it },
                                            label = { Text(if (isShows) "Show title" else when (current) {
                                                "Projects" -> "Project or task"
                                                "Family Calendar" -> "Event title"
                                                "Shopping" -> "Shopping item"
                                                "Ideas Workshop" -> "Idea title"
                                                "Memory" -> "Memory to save"
                                                else -> "Title"
                                            }) },
                                            modifier = Modifier.fillMaxWidth(), singleLine = true
                                        )
                                        OutlinedTextField(
                                            value = detailDraft, onValueChange = { detailDraft = it },
                                            label = { Text(if (isCalendar) "Date / time / details" else "Notes (optional)") },
                                            modifier = Modifier.fillMaxWidth(), minLines = 2
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = {
                                                addEntry(current, draft, detailDraft, if (isShows) category else "")
                                            }) { Text("Save") }
                                            OutlinedButton(onClick = { showComposer = false; draft = ""; detailDraft = "" }) { Text("Cancel") }
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            if (list.isEmpty()) {
                                EmptyState(current) { showComposer = true }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(9.dp),
                                    contentPadding = PaddingValues(bottom = 90.dp)
                                ) {
                                    itemsIndexed(list) { index, entry ->
                                        EntryCard(entry, onDelete = { removeEntry(current, index) })
                                    }
                                }
                            }
                        }
                        if (!showComposer) {
                            Button(
                                onClick = { showComposer = true },
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Purple)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (isIdeas) "Capture an idea" else "Add ${current.removeSuffix("s").lowercase()}")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarScreen(
    entries: List<LunaEntry>,
    onAdd: (String, String, String, String, String, String, String) -> Unit,
    onDelete: (Int) -> Unit
) {
    val today = remember { LocalDate.now() }
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var selectedDate by remember { mutableStateOf(today) }
    var composing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var child by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var repeat by remember { mutableStateOf("Does not repeat") }
    val iso = DateTimeFormatter.ISO_LOCAL_DATE
    val displayMonth = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())
    fun eventDate(entry: LunaEntry): String = entry.category.takeIf { it.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) } ?: ""
    fun eventField(entry: LunaEntry, key: String): String = entry.detail.lines().firstOrNull { it.startsWith("$key=") }?.substringAfter("=") ?: entry.detail
    val monthDays = remember(month) {
        val first = month.atDay(1)
        val leading = first.dayOfWeek.value % 7
        (List(leading) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) })
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Family Calendar", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Lilac)
                Text("School, sports, appointments, and family plans", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, "Previous month", tint = Lilac) }
            IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, "Next month", tint = Lilac) }
        }
        Spacer(Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(month.format(displayMonth), modifier = Modifier.weight(1f), color = Lilac, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { month = YearMonth.from(today); selectedDate = today }) { Text("Today") }
                }
                Row(Modifier.fillMaxWidth()) {
                    listOf("S", "M", "T", "W", "T", "F", "S").forEach { day ->
                        Text(day, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(5.dp))
                monthDays.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        week.forEach { date ->
                            Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp)) {
                                if (date != null) {
                                    val hasEvents = entries.any { eventDate(it) == date.format(iso) }
                                    val isSelected = date == selectedDate
                                    Column(
                                        Modifier.fillMaxSize().background(
                                            if (isSelected) Purple else if (date == today) Purple.copy(alpha = .20f) else Color.Transparent,
                                            RoundedCornerShape(10.dp)
                                        ).clickable { selectedDate = date }.padding(top = 5.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("${date.dayOfMonth}", color = if (isSelected) Color.White else Lilac, fontSize = 13.sp, fontWeight = if (date == today) FontWeight.Bold else FontWeight.Normal)
                                        if (hasEvents) Box(Modifier.padding(top = 2.dp).size(5.dp).background(if (isSelected) Color.White else Purple, CircleShape))
                                    }
                                }
                            }
                        }
                        repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMM d", Locale.getDefault())), color = Lilac, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                Text("${entries.count { eventDate(it) == selectedDate.format(iso) }} event(s)", color = Muted, fontSize = 12.sp)
            }
            Button(onClick = { title = ""; time = ""; child = ""; location = ""; notes = ""; repeat = "Does not repeat"; composing = true }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Add event")
            }
        }
        if (composing) {
            Spacer(Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Event title") }, singleLine = true)
                    Text("Date: ${selectedDate.format(iso)}", color = Muted, fontSize = 13.sp)
                    OutlinedTextField(time, { time = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Time (e.g. 3:30 PM)") }, singleLine = true)
                    OutlinedTextField(child, { child = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Child / family member") }, singleLine = true)
                    OutlinedTextField(location, { location = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Location") }, singleLine = true)
                    OutlinedTextField(notes, { notes = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Notes") }, minLines = 2)
                    Text("Repeat", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("Does not repeat", "Weekly").forEach { option ->
                            FilterChip(selected = repeat == option, onClick = { repeat = option }, label = { Text(option, fontSize = 11.sp) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { if (title.isNotBlank()) { onAdd(title.trim(), selectedDate.format(iso), time.trim(), child.trim(), location.trim(), notes.trim(), repeat); composing = false } }) { Text("Save event") }
                        OutlinedButton(onClick = { composing = false }) { Text("Cancel") }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        val dayEvents = entries.withIndex().filter { eventDate(it.value) == selectedDate.format(iso) }
        val legacy = entries.withIndex().filter { eventDate(it.value).isBlank() }
        val visible = dayEvents + if (selectedDate == today) legacy else emptyList()
        if (visible.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.EventAvailable, null, tint = Purple, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.height(8.dp)); Text("No events for this day", color = Lilac, fontWeight = FontWeight.SemiBold)
                    Text("Tap Add event to schedule something.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
                itemsIndexed(visible) { _, indexed ->
                    val entry = indexed.value
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(entry.title, color = Lilac, fontWeight = FontWeight.SemiBold)
                                val timeText = eventField(entry, "TIME")
                                val childText = eventField(entry, "CHILD")
                                val locationText = eventField(entry, "LOCATION")
                                if (timeText.isNotBlank()) Text(timeText, color = Purple, fontSize = 12.sp)
                                if (childText.isNotBlank()) Text("For: $childText", color = Muted, fontSize = 12.sp)
                                if (locationText.isNotBlank()) Text("Location: $locationText", color = Muted, fontSize = 12.sp)
                                val noteText = eventField(entry, "NOTES")
                                if (noteText.isNotBlank()) Text(noteText, color = Muted, fontSize = 12.sp)
                                val repeatText = eventField(entry, "REPEAT")
                                if (repeatText == "Weekly") Text("Repeats weekly (displayed event is saved locally)", color = Muted, fontSize = 11.sp)
                                if (eventDate(entry).isBlank()) Text("Older event — date not set", color = Muted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { onDelete(indexed.index) }) { Icon(Icons.Default.DeleteOutline, "Delete event", tint = Muted) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(entries: Map<String, List<LunaEntry>>, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Good to see you.", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Lilac)
                Spacer(Modifier.height(5.dp))
                Text("What would you like to work on today?", color = Muted)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryPill("Projects", (entries["Projects"] ?: emptyList()).size)
                    SummaryPill("Ideas", (entries["Ideas Workshop"] ?: emptyList()).size)
                    SummaryPill("Events", (entries["Family Calendar"] ?: emptyList()).size)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Your spaces", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Lilac)
        Spacer(Modifier.height(8.dp))
        val tiles = listOf(
            Triple("Projects", Icons.Default.CheckCircle, "Tasks and plans"),
            Triple("Family Calendar", Icons.Default.CalendarMonth, "Kids' activities and events"),
            Triple("Shopping", Icons.Default.ShoppingCart, "Lists for the next trip"),
            Triple("TV Shows", Icons.Default.LiveTv, "Watched, watching, and watchlist"),
            Triple("Ideas Workshop", Icons.Default.Lightbulb, "Save ideas whenever they strike"),
            Triple("Memory", Icons.Default.Bookmark, "Things you want WhippleHub to remember"),
            Triple("WhippleHub Chat", Icons.Default.ChatBubble, "Conversation demo"),
            Triple("Update Center", Icons.Default.SystemUpdateAlt, "Version and update settings")
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            itemsIndexed(tiles) { _, tile ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(tile.first) },
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(tile.second, null, tint = Purple, modifier = Modifier.size(25.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tile.first, fontWeight = FontWeight.SemiBold, color = Lilac)
                            Text(tile.third, fontSize = 12.sp, color = Muted)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.SummaryPill(label: String, count: Int) {
    Column(
        Modifier.weight(1f).background(Night, RoundedCornerShape(12.dp)).padding(10.dp)
    ) {
        Text("$count", color = Lilac, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun EntryCard(entry: LunaEntry, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                if (entry.category.isNotBlank()) {
                    Text(entry.category.uppercase(), color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(3.dp))
                }
                Text(entry.title, color = Lilac, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                if (entry.detail.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(entry.detail, color = Muted, fontSize = 13.sp)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, "Delete item", tint = Muted)
            }
        }
    }
}

@Composable
private fun EmptyState(section: String, onAdd: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(top = 35.dp, bottom = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            when (section) {
                "Projects" -> Icons.Default.CheckCircle
                "Family Calendar" -> Icons.Default.CalendarMonth
                "Shopping" -> Icons.Default.ShoppingCart
                "TV Shows" -> Icons.Default.LiveTv
                "Ideas Workshop" -> Icons.Default.Lightbulb
                "Memory" -> Icons.Default.Bookmark
                else -> Icons.Default.AutoAwesome
            }, null, tint = Purple, modifier = Modifier.size(42.dp)
        )
        Spacer(Modifier.height(10.dp))
        Text("Nothing here yet", color = Lilac, fontWeight = FontWeight.SemiBold)
        Text("Add your first item to get started.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onAdd) { Text("Add first item") }
    }
}

@Composable
private fun ChatScreen(log: List<String>, input: String, onInput: (String) -> Unit, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Talk with WhippleHub", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Lilac)
        Text("Conversation demo — real AI will be connected later.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            itemsIndexed(log) { _, line ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Text(line, Modifier.fillMaxWidth().padding(12.dp), color = Lilac, fontSize = 14.sp)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, onInput, modifier = Modifier.weight(1f), placeholder = { Text("Message WhippleHub…") }, singleLine = true)
            IconButton(onClick = onSend, modifier = Modifier.background(Purple, CircleShape)) {
                Icon(Icons.Default.Send, null, tint = Color.White)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun UpdateScreen() {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Update Center", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Lilac)
        Text("WhippleHub version 0.1.0 · Initial feature build", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp)) {
                Icon(Icons.Default.SystemUpdateAlt, null, tint = Purple, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(8.dp))
                Text("Update checks will be enabled after publishing", color = Lilac, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text("This starter project has no update server yet. A published Android app needs a secure release endpoint and a defined installation flow before automatic update notifications can work.", color = Muted, fontSize = 13.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp)) {
                Text("Planned next", color = Lilac, fontWeight = FontWeight.SemiBold)
                Text("• Connect a real AI provider\n• Add a release/update service\n• Add backups and restore\n• Build and test a signed APK", color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
            }
        }
    }
}

private fun sectionSubtitle(section: String) = when (section) {
    "TV Shows" -> "Keep watched shows, current shows, and future picks organized."
    "Projects" -> "Capture projects, tasks, and the things you want to get done."
    "Family Calendar" -> "Track school, sports, appointments, and family events."
    "Shopping" -> "Keep shopping items in one simple list."
    "Ideas Workshop" -> "Save ideas now and develop them into projects later."
    "Memory" -> "A private, locally saved notebook for useful details."
    else -> "Your information stays on this device in this starter build."
}

private fun loadAll(context: Context): Map<String, List<LunaEntry>> {
    val prefs = context.getSharedPreferences("luna_local_data", Context.MODE_PRIVATE)
    val raw = prefs.getString("entries", null) ?: return emptyMap()
    return try {
        val root = JSONObject(raw)
        val result = mutableMapOf<String, List<LunaEntry>>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val arr = root.optJSONArray(key) ?: JSONArray()
            val list = mutableListOf<LunaEntry>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(LunaEntry(
                    obj.optString("title"),
                    obj.optString("detail"),
                    obj.optString("category")
                ))
            }
            result[key] = list
        }
        result
    } catch (_: Exception) { emptyMap() }
}

private fun saveAll(context: Context, entries: Map<String, List<LunaEntry>>) {
    val root = JSONObject()
    entries.forEach { (section, list) ->
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(JSONObject().put("title", item.title).put("detail", item.detail).put("category", item.category))
        }
        root.put(section, arr)
    }
    context.getSharedPreferences("luna_local_data", Context.MODE_PRIVATE)
        .edit().putString("entries", root.toString()).apply()
}
