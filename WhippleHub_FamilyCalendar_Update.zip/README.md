# WhippleHub Android starter project

WhippleHub is a native Android app built with Kotlin and Jetpack Compose. Formal branding: **WhippleHub — A Product by Whipple Corporation**.

## Included in this first feature build
- Dark purple Luna interface
- Home dashboard and feature navigation
- TV Show Tracker with Watched, Currently Watching, and Watchlist categories
- Projects and task capture
- Family Calendar with a monthly grid, month navigation, day selection, event dates, times, child/family member, location, notes, weekly-repeat setting, and delete controls
- Shopping list
- Ideas Workshop
- Local Memory notebook
- Luna Chat placeholder
- Update Center placeholder
- Local storage using Android SharedPreferences

## Important current limitations
- This is source code, not a prebuilt APK.
- Chat is scripted and does not connect to an AI service yet.
- The Update Center is a placeholder; a secure release endpoint and Android installation/update strategy must be configured before update checks can work.
- Calendar events are stored locally on this device. Google Calendar sync and Android notification delivery are not implemented yet. The weekly-repeat setting is saved as event metadata; it does not currently generate additional calendar occurrences.
- Data is stored on this device. Cloud sync and backup/restore are not included yet.

## Build an APK
1. Install Android Studio (current stable version) and a JDK 17-compatible setup.
2. Open this folder in Android Studio.
3. Allow Gradle to sync and download dependencies.
4. If prompted, install Android SDK Platform 35 and the required build tools.
5. Run the app on an Android device or emulator.
6. To make a test APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. For distribution, configure signing under **Build > Generate Signed Bundle / APK**.

## Suggested development order
1. Test and refine the local feature screens.
2. Add structured calendar dates, child profiles, reminders, and repeat events.
3. Add edit/search/filter and data export/restore.
4. Connect a real AI provider securely through a backend (do not embed private API keys in the APK).
5. Build a release/update service and choose a supported Android update delivery method.


## Build without owning a computer (phone-only route)
This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It can compile a debug APK on GitHub's cloud runners. You need a GitHub account and must upload the project files into a repository (the ZIP itself is not a source repository).

Phone workflow:
1. In your phone browser, create a new repository on GitHub.
2. Upload/extract the project files into the repository so `settings.gradle.kts`, `build.gradle.kts`, and `app/` are at the repository root. Also include `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab and choose **Build WhippleHub APK**.
4. Tap **Run workflow** if it has not started automatically.
5. When the run succeeds, open it and download the **WhippleHub-debug-APK** artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Open the APK on your phone to install it. Android may ask you to allow installation from that browser or file manager.

Notes:
- A debug APK is for personal testing, not a signed Play Store release.
- GitHub's mobile website can make uploading nested folders awkward. If this gets frustrating, use a cloud Android IDE such as Android Studio Cloud where available, or a trusted helper to do the initial repository upload.
- This workflow has not been run in this environment, so the build still needs to pass on the cloud runner before the APK can be considered usable.
